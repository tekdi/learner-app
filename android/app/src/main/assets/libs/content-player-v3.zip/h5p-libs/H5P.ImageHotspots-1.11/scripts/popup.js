/**
 * Defines the ImageHotspots.Popup class
 */
(function ($, ImageHotspots, EventDispatcher) {
  /**
   * Creates new Popup instance
   *
   * @class
   * @namespace H5P.ImageHotspots
   * @param {H5P.jQuery} $container
   * @param {H5P.jQuery} $content
   * @param {number} x
   * @param {number} y
   * @param {number} hotspotWidth
   * @param {string} header
   * @param {string} className
   * @param {boolean} fullscreen
   * @param {Object} options
   *
   */
  ImageHotspots.Popup = function ($container, $content, x, y, hotspotWidth, header, className, fullscreen, options, legacy) {
    EventDispatcher.call(this);

    const self = this;
    this.$container = $container;
    const width = this.$container.width();
    let height = this.$container.height();

    const pointerWidthInPercent = 1.55;
    hotspotWidth = (hotspotWidth / width) * 100;

    let popupLeft = 0;
    let popupWidth = 0;
    let toTheLeft = false;

    if (fullscreen) {
      popupWidth = 100;
      className += ' fullscreen-popup';
    }
    else {
      toTheLeft = (x > 50);
      popupLeft = (toTheLeft ? 0 : (x + hotspotWidth + pointerWidthInPercent));
      popupWidth = (toTheLeft ? (x - hotspotWidth - pointerWidthInPercent) : 100 - popupLeft);
    }

    this.$popupBackground = $('<div/>', {
      class: 'h5p-image-hotspots-overlay',
      id: 'h5p-image-hotspots-overlay',
    });
    const headerID = `h5p-image-hotspot-popup-header-${H5P.createUUID()}`;
    this.$popup = $('<div/>', {
      class: `h5p-image-hotspot-popup ${className}`,
      tabindex: '0',
      role: 'dialog',
      'aria-modal': 'true',
      'aria-labelledby': header ? headerID : undefined,
    }).css({
      left: `${toTheLeft ? '' : '-'}100%`,
      width: `${popupWidth}%`,
    }).appendTo(this.$popupBackground);

    this.$popupContent = $('<div/>', {
      class: 'h5p-image-hotspot-popup-content',
      on: {
        scroll() {
          $(this).addClass('has-scrolled');
        },
      },
    });

    if (header) {
      this.$popupHeader = $('<div/>', {
        class: 'h5p-image-hotspot-popup-header',
        id: headerID,
        html: header,
        'aria-hidden': 'true',
      });
      this.$popupContent.append(this.$popupHeader);
      this.$popup.addClass('h5p-image-hotspot-has-header');
    }
    $content.appendTo(this.$popupContent);
    this.$popupContent.appendTo(this.$popup);

    // Add close button
    this.$closeButton = $('<button>', {
      class: 'h5p-image-hotspot-close-popup-button',
      'aria-label': options.closeButtonLabel,
      title: options.closeButtonLabel,
    }).click(() => {
      self.trigger('closed');
    }).keydown((e) => {
      if (e.which === 32 || e.which === 13) {
        self.trigger('closed', { refocus: true });
        return false;
      }
    }).appendTo(this.$popup);

    if (!header) {
      self.$popupContent.addClass('h5p-image-hotspot-popup-content-no-header');
    }

    // Need to add pointer to parent container, since this should be partly covered
    // by the popup
    if (!fullscreen) {
      this.$pointer = $('<div/>', {
        class: `h5p-image-hotspot-popup-pointer to-the-${toTheLeft ? 'left' : 'right'}${legacy ? ' legacy-positioning' : ''}`,
      }).css({
        top: `${y}%`,
      }).appendTo(this.$popupBackground);
    }

    this.$popupBackground.appendTo(this.$container);

    self.resize = function () {
      if (fullscreen) {
        return;
      }

      // Reset
      self.$popup.css({
        maxHeight: '',
        height: '',
      });
      self.$popupContent.css({
        height: '',
      });

      height = this.$container.height();
      const contentHeight = self.$popupContent.outerHeight();
      const parentHeight = self.$popup.outerHeight();

      const fitsWithin = contentHeight < height;

      if (fitsWithin) {
        // don't need all height:
        self.$popup.css({
          maxHeight: 'auto',
          height: 'auto',
        });

        // find new top:
        let top = Math.max(0, ((y / 100) * parentHeight) - (contentHeight / 2));

        // Check if we need to move it a bit up (in case it overflows)
        if (top + contentHeight > parentHeight) {
          top = parentHeight - contentHeight;
        }

        // From pixels to percent:
        self.$popup.css({
          top: `${(top / parentHeight) * 100}%`,
        });
      }

      self.$popupContent.css({
        height: fitsWithin ? '' : '100%',
        overflow: fitsWithin ? '' : 'auto',
      }).toggleClass('overflowing', !fitsWithin);

      self.$popup.toggleClass('popup-overflowing', !fitsWithin);
    };

    /**
     * Show popup
     */
    self.show = function () {
      if (!fullscreen) {
        self.resize();

        // Need to move pointer:
        self.$pointer.css({
          left: toTheLeft ? (
            `${popupWidth}%`
          ) : (
            `${popupLeft}%`
          ),
        });
      }

      self.$popup.css({
        left: `${popupLeft}%`,
      });
      self.$popupBackground.addClass('visible');

      H5P.Transition.onTransitionEnd(self.$popup, () => {
        self.$popup.focus();

        // Show pointer;
        if (self.$pointer) {
          self.$pointer.addClass('visible');
        }
        self.trigger('finishedLoading');
      }, 300);
    };

    self.hide = function () {
      self.$popupBackground.remove();
    };
  };

  // Extends the event dispatcher
  ImageHotspots.Popup.prototype = Object.create(EventDispatcher.prototype);
  ImageHotspots.Popup.prototype.constructor = ImageHotspots.Popup;
}(H5P.jQuery, H5P.ImageHotspots, H5P.EventDispatcher));
